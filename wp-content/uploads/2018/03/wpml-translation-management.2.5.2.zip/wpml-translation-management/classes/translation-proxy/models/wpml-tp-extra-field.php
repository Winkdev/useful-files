<?php

/**
 * @author OnTheGo Systems
 */
class WPML_TP_Extra_Field {
	/** @var string */
	public $type = 'text';
	/** @var string */
	public $label;
	/** @var string */
	public $name;
	/** @var array */
	public $items;
}